import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Zap, Target, Users } from 'lucide-react';

const reasons = [
  {
    title: "Local Expertise",
    description: "Based in Point Cook, we understand the local market and what Melbourne businesses need to succeed.",
    icon: Users
  },
  {
    title: "High Performance",
    description: "Our sites are built for speed and conversion, ensuring your visitors have a seamless experience.",
    icon: Zap
  },
  {
    title: "SEO Focused",
    description: "We don't just build sites; we build them to be found. Every project includes basic SEO setup.",
    icon: Target
  },
  {
    title: "Proven Results",
    description: "With a 5.0-star rating and dozens of successful projects, we have a track record you can trust.",
    icon: CheckCircle2
  }
];

export const WhyChooseUs = () => {
  return (
    <section className="py-24 bg-background dark:bg-background overflow-hidden">
      <div className="max-w-4xl mx-auto px-6">
        <div className="flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl"
          >
            <h2 className="text-4xl md:text-5xl font-bold font-sans mb-6 text-foreground">
              Why Local Businesses <span className="text-primary">Choose ClearSite</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-12 leading-relaxed">
              We're not just another web agency. We're your local partners in digital growth. We focus on what matters: getting you more enquiries and building a professional online presence that represents your brand perfectly.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
              {reasons.map((reason, index) => (
                <div key={index} className="flex gap-4 p-6 rounded-2xl bg-card border border-border">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <reason.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold font-sans mb-1 text-foreground">{reason.title}</h4>
                    <p className="text-muted-foreground text-sm">{reason.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
