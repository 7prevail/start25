import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    name: "Verified Client",
    role: "Local Cafe Owner",
    content: "ClearSite transformed our online presence. We've seen a 40% increase in bookings since the new site launched. Professional, fast, and local!",
    rating: 5,
    avatar: "https://picsum.photos/seed/sarah/100/100"
  },
  {
    name: "Verified Client",
    role: "Plumbing Services",
    content: "I was skeptical about SEO, but ClearSite delivered. I'm now ranking #1 for 'plumber Point Cook'. Best investment I've made for my business.",
    rating: 5,
    avatar: "https://picsum.photos/seed/mark/100/100"
  },
  {
    name: "Verified Client",
    role: "Boutique Fashion",
    content: "The design is stunning! It perfectly captures our brand's aesthetic. The team was incredibly patient and responsive throughout the process.",
    rating: 5,
    avatar: "https://picsum.photos/seed/elena/100/100"
  },
  {
    name: "Verified Client",
    role: "Tech Startup Founder",
    content: "High-performance code and beautiful UI. ClearSite knows how to build for conversion. Highly recommended for any serious business.",
    rating: 5,
    avatar: "https://picsum.photos/seed/david/100/100"
  }
];

export const ReviewsSection = () => {
  return (
    <section id="reviews" className="py-24 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold font-sans mb-4 text-foreground"
          >
            What Our Clients Say
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto text-lg"
          >
            We've helped dozens of local businesses in Point Cook and beyond grow their online presence.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-3xl bg-card border border-border relative group"
            >
              <p className="text-foreground mb-8 relative z-10 italic">
                "{review.content}"
              </p>

              <div className="flex items-center gap-4">
                <div>
                  <h4 className="font-bold text-foreground">{review.name}</h4>
                  <p className="text-sm text-muted-foreground">{review.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
