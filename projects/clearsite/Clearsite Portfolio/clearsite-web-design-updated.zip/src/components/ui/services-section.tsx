import React from 'react';
import { motion } from 'motion/react';
import { Globe, Search, Zap, Shield, Layout, Smartphone } from 'lucide-react';

const services = [
  {
    title: "Web Design",
    description: "Custom, high-performance websites that convert visitors into loyal customers.",
    icon: Globe,
    color: "bg-chart-1/10 text-chart-1"
  },
  {
    title: "SEO Optimization",
    description: "Rank higher on Google and get found by local customers in Point Cook and beyond.",
    icon: Search,
    color: "bg-chart-2/10 text-chart-2"
  },
  {
    title: "Speed Optimization",
    description: "Lightning-fast load times to improve user experience and search engine rankings.",
    icon: Zap,
    color: "bg-chart-3/10 text-chart-3"
  },
  {
    title: "Maintenance & Security",
    description: "Ongoing support, updates, and security monitoring to keep your site running smoothly.",
    icon: Shield,
    color: "bg-chart-4/10 text-chart-4"
  },
  {
    title: "UI/UX Design",
    description: "Intuitive user interfaces and engaging user experiences tailored to your brand.",
    icon: Layout,
    color: "bg-chart-5/10 text-chart-5"
  },
  {
    title: "Mobile First",
    description: "Responsive designs that look and work perfectly on all devices, from phones to desktops.",
    icon: Smartphone,
    color: "bg-primary/10 text-primary"
  }
];

export const ServicesSection = () => {
  return (
    <section id="services" className="py-24 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold font-sans mb-4 text-foreground"
          >
            Our Services
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto text-lg"
          >
            We offer a comprehensive range of web design and digital marketing services to help your business thrive online.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-3xl bg-card border border-border hover:border-primary/50 transition-all group shadow-sm hover:shadow-xl"
            >
              <div className={`w-14 h-14 rounded-2xl ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <service.icon className="w-8 h-8" />
              </div>
              
              <h3 className="text-2xl font-bold font-sans mb-4 text-foreground">
                {service.title}
              </h3>
              
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
