"use client";
import { motion, useScroll, useTransform, Variants } from "framer-motion";
import React from "react";
import { cn } from "@/src/lib/utils";

interface TimelineContentProps {
  children: React.ReactNode;
  timelineRef: React.RefObject<HTMLElement | null>;
  animationNum: number;
  customVariants?: Variants;
  className?: string;
  as?: any;
}

export const TimelineContent = ({
  children,
  timelineRef,
  animationNum,
  customVariants,
  className,
  as = "div",
}: TimelineContentProps) => {
  const MotionTag = motion[as as keyof typeof motion] as typeof motion.div;

  const defaultVariants: Variants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        delay: animationNum * 0.1,
      },
    },
  };

  return (
    <MotionTag
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={customVariants || defaultVariants}
      className={cn(className)}
    >
      {children}
    </MotionTag>
  );
};
