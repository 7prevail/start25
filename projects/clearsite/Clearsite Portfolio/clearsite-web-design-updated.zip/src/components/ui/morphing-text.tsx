import React, { useEffect, useRef } from 'react';

const words = [
  "convert",
  "scale",
  "engage",
  "capture",
  "rank",
  "retain",
  "dominate",
  "accelerate"
];

export const MorphingText = () => {
  const text1Ref = useRef<HTMLSpanElement>(null);
  const text2Ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    let wordIndex = words.length - 1;
    const morphTime = 1;
    const cooldownTime = 0.5;

    let morph = 0;
    let cooldown = cooldownTime;
    let lastTime = Date.now();

    const setMorph = (fraction: number) => {
      const safeFraction = Math.max(fraction, 0.0001);
      
      if (text1Ref.current && text2Ref.current) {
        text2Ref.current.style.filter = `blur(${Math.min(6 / safeFraction - 6, 60)}px)`;
        text2Ref.current.style.opacity = `${Math.pow(fraction, 0.4)}`;

        const inv = 1 - fraction;
        const safeInv = Math.max(inv, 0.0001);
        text1Ref.current.style.filter = `blur(${Math.min(6 / safeInv - 6, 60)}px)`;
        text1Ref.current.style.opacity = `${Math.pow(inv, 0.4)}`;

        text1Ref.current.textContent = words[wordIndex % words.length];
        text2Ref.current.textContent = words[(wordIndex + 1) % words.length];
      }
    };

    const doMorph = () => {
      morph -= cooldown;
      cooldown = 0;

      let fraction = morph / morphTime;

      if (fraction > 1) {
        cooldown = cooldownTime;
        fraction = 1;
      }

      // smooth easing
      fraction = 1 - Math.pow(1 - fraction, 3);

      setMorph(fraction);
    };

    const doCooldown = () => {
      morph = 0;

      if (text1Ref.current && text2Ref.current) {
        text2Ref.current.style.filter = "";
        text2Ref.current.style.opacity = "1";

        text1Ref.current.style.filter = "";
        text1Ref.current.style.opacity = "0";
      }
    };

    const animate = () => {
      const animationId = requestAnimationFrame(animate);

      const newTime = Date.now();
      const dt = (newTime - lastTime) / 1000;
      lastTime = newTime;

      cooldown -= dt;

      if (cooldown <= 0) {
        if (cooldown + dt > 0) {
          wordIndex++;
        }
        doMorph();
      } else {
        doCooldown();
      }

      return animationId;
    };

    const animationId = animate();

    return () => cancelAnimationFrame(animationId);
  }, []);

  return (
    <div className="relative inline-block align-baseline min-w-[180px] text-center">
      <span
        ref={text1Ref}
        className="absolute left-1/2 top-0 -translate-x-1/2 whitespace-nowrap text-primary"
      ></span>
      <span
        ref={text2Ref}
        className="absolute left-1/2 top-0 -translate-x-1/2 whitespace-nowrap text-primary"
      ></span>
      
      {/* SVG filter for the morph effect */}
      <svg className="absolute h-0 w-0 invisible" aria-hidden="true">
        <defs>
          <filter id="threshold">
            <feColorMatrix
              in="SourceGraphic"
              type="matrix"
              values="
                1 0 0 0 0
                0 1 0 0 0
                0 0 1 0 0
                0 0 0 255 -140"
            />
          </filter>
        </defs>
      </svg>
      
      {/* Invisible spacer to maintain layout height/width based on the longest word */}
      <span className="opacity-0 pointer-events-none select-none invisible">accelerate</span>
    </div>
  );
};
