/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HeroSection } from "@/src/components/ui/hero-section-1";
import PricingSection6 from "@/src/components/ui/pricing-section-4";
import { ReviewsSection } from "@/src/components/ui/reviews-section";
import { ServicesSection } from "@/src/components/ui/services-section";
import { Footer } from "@/src/components/ui/footer";
import { WhyChooseUs } from "@/src/components/ui/why-choose-us";
import { ThemeProvider } from "@/src/components/theme-provider";
import { Contact2 } from "@/src/components/ui/contact-2";

export default function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="clearsite-theme">
      <div className="min-h-screen bg-background text-foreground selection:bg-primary/20 selection:text-primary">
        <HeroSection />
        
        <ServicesSection />

        <WhyChooseUs />

        <ReviewsSection />

        <PricingSection6 />

        <Contact2 
          title="Get in Touch"
          description="Ready to start your project? Have questions about my services? I'm here to help you build a better online presence."
        />

        <Footer />
      </div>
    </ThemeProvider>
  );
}
