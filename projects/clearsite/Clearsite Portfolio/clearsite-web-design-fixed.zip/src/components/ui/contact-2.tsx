import React, { useState } from "react";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";
import { Label } from "@/src/components/ui/label";
import { Textarea } from "@/src/components/ui/textarea";

interface Contact2Props {
  title?: string;
  description?: string;
}

// Sanitise: strip HTML tags and trim
const sanitise = (val: string) => val.replace(/<[^>]*>/g, "").trim();

// Rate limiter: max 3 submissions per 10 minutes (client-side)
const RATE_LIMIT = 3;
const RATE_WINDOW = 10 * 60 * 1000;
const attempts: number[] = [];
const isRateLimited = () => {
  const now = Date.now();
  while (attempts.length && now - attempts[0] > RATE_WINDOW) attempts.shift();
  return attempts.length >= RATE_LIMIT;
};

const validate = (fields: Record<string, string>) => {
  const errors: Record<string, string> = {};
  if (!fields.firstname || fields.firstname.length < 2) errors.firstname = "Enter a valid first name.";
  if (!fields.lastname || fields.lastname.length < 2) errors.lastname = "Enter a valid last name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) errors.email = "Enter a valid email address.";
  if (!fields.subject || fields.subject.length < 3) errors.subject = "Subject must be at least 3 characters.";
  if (!fields.message || fields.message.length < 10) errors.message = "Message must be at least 10 characters.";
  if (fields.message.length > 2000) errors.message = "Message must be under 2000 characters.";
  return errors;
};

export const Contact2 = ({
  title = "Contact Us",
  description = "We are available for questions, feedback, or collaboration opportunities. Let us know how we can help!",
}: Contact2Props) => {
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (isRateLimited()) {
      setStatus("error");
      setErrors({ form: "Too many submissions. Please wait a few minutes and try again." });
      return;
    }

    const form = e.currentTarget;
    const raw = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
    const fields = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, sanitise(v)]));

    const fieldErrors = validate(fields);
    if (Object.keys(fieldErrors).length) {
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setStatus("submitting");
    attempts.push(Date.now());

    const data = new FormData();
    Object.entries(fields).forEach(([k, v]) => data.append(k, v));

    const response = await fetch("https://formspree.io/f/xqegpeop", {
      method: "POST",
      body: data,
      headers: { Accept: "application/json" },
    });

    if (response.ok) {
      setStatus("success");
      form.reset();
    } else {
      setStatus("error");
      setErrors({ form: "Something went wrong. Please try again." });
    }
  };

  return (
    <section className="py-32" id="contact">
      <div className="container mx-auto px-4">
        <div className="mx-auto flex max-w-screen-xl flex-col justify-between gap-10 lg:flex-row lg:gap-20">
          <div className="mx-auto flex max-w-sm flex-col justify-center gap-10">
            <div className="text-center lg:text-left">
              <h1 className="mb-2 text-5xl font-semibold lg:mb-1 lg:text-6xl">{title}</h1>
              <p className="text-muted-foreground">{description}</p>
            </div>
          </div>
          <div className="mx-auto flex w-full max-w-screen-md flex-col gap-6 rounded-lg border bg-card p-10 text-card-foreground shadow-sm">
            {status === "success" ? (
              <div className="flex flex-col items-center justify-center gap-4 py-10 text-center">
                <div className="text-4xl">✅</div>
                <h2 className="text-2xl font-semibold">Message Sent!</h2>
                <p className="text-muted-foreground">Thanks for reaching out. We'll get back to you soon.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-6" noValidate>
                <div className="flex flex-col gap-4 sm:flex-row">
                  {(["firstname", "lastname"] as const).map((field) => (
                    <div key={field} className="grid w-full items-center gap-1.5">
                      <Label htmlFor={field}>{field === "firstname" ? "First Name" : "Last Name"}</Label>
                      <Input type="text" id={field} name={field} placeholder={field === "firstname" ? "First Name" : "Last Name"} maxLength={50} />
                      {errors[field] && <p className="text-xs text-red-500">{errors[field]}</p>}
                    </div>
                  ))}
                </div>
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input type="email" id="email" name="email" placeholder="Email" maxLength={254} />
                  {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}
                </div>
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="subject">Subject</Label>
                  <Input type="text" id="subject" name="subject" placeholder="Subject" maxLength={100} />
                  {errors.subject && <p className="text-xs text-red-500">{errors.subject}</p>}
                </div>
                <div className="grid w-full gap-1.5">
                  <Label htmlFor="message">Message</Label>
                  <Textarea placeholder="Type your message here." id="message" name="message" maxLength={2000} />
                  {errors.message && <p className="text-xs text-red-500">{errors.message}</p>}
                </div>
                {errors.form && <p className="text-sm text-red-500">{errors.form}</p>}
                <Button type="submit" className="w-full" disabled={status === "submitting"}>
                  {status === "submitting" ? "Sending…" : "Send Message"}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
