"use client";
import { Card, CardContent, CardHeader } from "@/src/components/ui/card";
import { Sparkles as SparklesComp } from "@/src/components/ui/sparkles";
import { TimelineContent } from "@/src/components/ui/timeline-animation";
import {VerticalCutReveal} from "@/src/components/ui/vertical-cut-reveal";
import { cn } from "@/src/lib/utils";
import NumberFlow from "@number-flow/react";
import { motion } from "framer-motion";
import { useRef, useState } from "react";

const plans = [
  {
    name: "Starter",
    description:
      "Perfect if you just need something clean and professional online fast.",
    price: 499,
    yearlyPrice: 499, // One-time payment in original, but keeping component structure
    buttonText: "Get Started",
    buttonVariant: "outline" as const,
    includes: [
      "Plan includes:",
      "1-page website",
      "Contact form",
      "Google Maps",
      "1 month support",
    ],
  },
  {
    name: "Standard",
    description:
      "The go-to for businesses that want to stand out and start getting more enquiries.",
    price: 799,
    yearlyPrice: 799,
    buttonText: "Get Started",
    buttonVariant: "default" as const,
    popular: true,
    includes: [
      "Everything in Starter, plus:",
      "Up to 5 pages",
      "Custom design",
      "Quote request form",
      "SEO setup",
      "Google Maps + Reviews",
      "Photo gallery",
      "3 months support",
    ],
  },
  {
    name: "Premium",
    description:
      "For businesses ready to have a serious online presence that sets them apart.",
    price: 1299,
    yearlyPrice: 1299,
    buttonText: "Get Started",
    buttonVariant: "outline" as const,
    includes: [
      "Everything in Standard, plus:",
      "Unlimited pages",
      "Full custom design",
      "Speed optimised",
      "Priority support",
      "6 months support",
    ],
  },
];

const PricingSwitch = ({ onSwitch }: { onSwitch: (value: string) => void }) => {
  const [selected, setSelected] = useState("0");

  const handleSwitch = (value: string) => {
    setSelected(value);
    onSwitch(value);
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative mx-auto flex w-fit rounded-full bg-card border border-border p-1">
        <button
          onClick={() => handleSwitch("0")}
          className={cn(
            "relative z-10 w-fit h-10  rounded-full sm:px-6 px-3 sm:py-2 py-1 font-medium transition-colors",
            selected === "0" ? "text-primary-foreground" : "text-muted-foreground",
          )}
        >
          {selected === "0" && (
            <motion.span
              layoutId={"switch"}
              className="absolute top-0 left-0 h-10 w-full rounded-full border-4 shadow-sm shadow-primary border-primary bg-gradient-to-t from-primary to-chart-2"
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
          )}
          <span className="relative">One-time</span>
        </button>

        <button
          onClick={() => handleSwitch("1")}
          className={cn(
            "relative z-10 w-fit h-10 flex-shrink-0 rounded-full sm:px-6 px-3 sm:py-2 py-1 font-medium transition-colors",
            selected === "1" ? "text-primary-foreground" : "text-muted-foreground",
          )}
        >
          {selected === "1" && (
            <motion.span
              layoutId={"switch"}
              className="absolute top-0 left-0 h-10 w-full  rounded-full border-4 shadow-sm shadow-primary border-primary bg-gradient-to-t from-primary to-chart-2"
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
          )}
          <span className="relative flex items-center gap-2">Maintenance</span>
        </button>
      </div>
      {selected === "1" && (
        <motion.p 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-primary font-bold font-sans"
        >
          🔧 Monthly Maintenance: $79/month
        </motion.p>
      )}
    </div>
  );
};

export default function PricingSection6() {
  const [isYearly, setIsYearly] = useState(false);
  const pricingRef = useRef<HTMLDivElement>(null);

  const revealVariants = {
    visible: (i: number) => ({
      y: 0,
      opacity: 1,
      filter: "blur(0px)",
      transition: {
        delay: i * 0.4,
        duration: 0.5,
      },
    }),
    hidden: {
      filter: "blur(10px)",
      y: -20,
      opacity: 0,
    },
  };

  const togglePricingPeriod = (value: string) =>
    setIsYearly(Number.parseInt(value) === 1);

  return (
    <div
      id="pricing"
      className=" min-h-screen  mx-auto relative bg-background overflow-x-hidden"
      ref={pricingRef}
    >
      <TimelineContent
        animationNum={4}
        timelineRef={pricingRef}
        customVariants={revealVariants}
        className="absolute top-0  h-96 w-screen overflow-hidden [mask-image:radial-gradient(50%_50%,white,transparent)] "
      >
        <div className="absolute bottom-0 left-0 right-0 top-0 bg-[linear-gradient(to_right,#6366f12c_1px,transparent_1px),linear-gradient(to_bottom,#6366f101_1px,transparent_1px)] bg-[size:70px_80px] "></div>
        <SparklesComp
          density={1800}
          direction="bottom"
          speed={1}
          color="#6366f1"
          className="absolute inset-x-0 bottom-0 h-full w-full [mask-image:radial-gradient(50%_50%,white,transparent_85%)]"
        />
      </TimelineContent>
      <TimelineContent
        animationNum={5}
        timelineRef={pricingRef}
        customVariants={revealVariants}
        className="absolute left-0 top-[-114px] w-full h-[113.625vh] flex flex-col items-start justify-start content-start flex-none flex-nowrap gap-2.5 overflow-hidden p-0 z-0"
      >
        <div className="framer-1i5axl2">
          <div
            className="absolute left-[-568px] right-[-568px] top-0 h-[2053px] flex-none rounded-full"
            style={{
              border: "200px solid var(--primary)",
              filter: "blur(92px)",
              WebkitFilter: "blur(92px)",
            }}
          ></div>
          <div
            className="absolute left-[-568px] right-[-568px] top-0 h-[2053px] flex-none rounded-full"
            style={{
              border: "200px solid var(--primary)",
              filter: "blur(92px)",
              WebkitFilter: "blur(92px)",
            }}
          ></div>
        </div>
      </TimelineContent>

      <article className="text-center mb-6 pt-32 max-w-3xl mx-auto space-y-2 relative z-20">
        <h2 className="text-4xl font-medium text-foreground">
          <VerticalCutReveal
            splitBy="words"
            staggerDuration={0.15}
            staggerFrom="first"
            reverse={true}
            containerClassName="justify-center "
            transition={{
              type: "spring",
              stiffness: 250,
              damping: 40,
              delay: 0, // First element
            }}
          >
            Plans that works best for your
          </VerticalCutReveal>
        </h2>

        <TimelineContent
          as="p"
          animationNum={0}
          timelineRef={pricingRef}
          customVariants={revealVariants}
          className="text-muted-foreground"
        >
          Trusted by millions, We help teams all around the world, Explore which
          option is right for you.
        </TimelineContent>

        <TimelineContent
          as="div"
          animationNum={1}
          timelineRef={pricingRef}
          customVariants={revealVariants}
        >
          <PricingSwitch onSwitch={togglePricingPeriod} />
        </TimelineContent>
      </article>

      <div
        className="absolute top-0 left-[10%] right-[10%] w-[80%] h-full z-0"
        style={{
          backgroundImage: `
        radial-gradient(circle at center, var(--primary) 0%, transparent 70%)
      `,
          opacity: 0.6,
          mixBlendMode: "multiply",
        }}
      />

      <div className="grid md:grid-cols-3 max-w-5xl gap-4 py-6 mx-auto ">
        {plans.map((plan, index) => (
          <div key={plan.name} className="relative hover:z-30 transition-all duration-300">
            <TimelineContent
              as="div"
              animationNum={2 + index}
              timelineRef={pricingRef}
              customVariants={revealVariants}
              className="overflow-visible"
            >
              <Card
                className={cn(
                  "relative text-foreground border-border bg-card transition-all duration-500",
                  "hover:shadow-[0px_0px_150px_0px_var(--primary),-50px_0px_150px_-20px_var(--primary),50px_0px_150px_-20px_var(--primary)] hover:scale-[1.02]",
                  plan.popular ? "z-20 border-primary/50" : "z-10"
                )}
              >
                <CardHeader className="text-left ">
                  <div className="flex justify-between">
                    <h3 className="text-3xl mb-2">{plan.name}</h3>
                  </div>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-semibold ">
                      $
                      <NumberFlow
                        format={{
                          currency: "USD",
                        }}
                        value={isYearly ? plan.yearlyPrice : plan.price}
                        className="text-4xl font-semibold"
                      />
                    </span>
                    <span className="text-muted-foreground ml-1">
                      /{isYearly ? "year" : "month"}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                </CardHeader>

                <CardContent className="pt-0">
                  <button
                    className={`w-full mb-6 p-4 text-xl rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] ${
                      plan.popular
                        ? "bg-gradient-to-t from-primary to-chart-2 shadow-lg shadow-primary/40 border border-primary text-primary-foreground"
                        : plan.buttonVariant === "outline"
                          ? "bg-card border border-border text-foreground hover:bg-muted"
                          : ""
                    }`}
                  >
                    {plan.buttonText}
                  </button>

                  <div className="space-y-3 pt-4 border-t border-border">
                    <h4 className="font-medium text-base mb-3">
                      {plan.includes[0]}
                    </h4>
                    <ul className="space-y-2">
                      {plan.includes.slice(1).map((feature, featureIndex) => (
                        <li
                          key={featureIndex}
                          className="flex items-center gap-2"
                        >
                          <span className="h-2.5 w-2.5 bg-primary rounded-full grid place-content-center"></span>
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TimelineContent>
          </div>
        ))}
      </div>
    </div>
  );
}
